public enum ProductType
{
    Airplane, Background
}
